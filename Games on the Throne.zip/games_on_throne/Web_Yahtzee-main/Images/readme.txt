These images were produced by the Microsoft Visio 2016 files dice.vsdx and diceX.vsdx.

You are welcome to use these resources as they are, modify them, or make your own.